package LibrarySystems.controllers;
import LibrarySystems.dao.FeedbackDAO;
import LibrarySystems.models.Feedback;
import java.util.List;


public class FeedbackController {
    private FeedbackDAO feedbackDAO;

    public FeedbackController() {
        feedbackDAO = new FeedbackDAO();
    }

    public void addFeedback(String studentName, String message) {
        Feedback feedback = new Feedback(studentName, message);
        feedbackDAO.addFeedback(feedback);
    }

    public List<Feedback> getAllFeedback() {
        return feedbackDAO.getAllFeedback();
    }

    //Update feedback
    public void updateFeedback(int id, String name, String message) {
        Feedback feedback = new Feedback(id, name, message);
        feedbackDAO.updateFeedback(feedback);
    }

    //Delete feedback
    public void deleteFeedback(int id) {
        feedbackDAO.deleteFeedback(id);
    }
}
