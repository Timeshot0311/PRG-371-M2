package LibrarySystems.controllers;

import LibrarySystems.models.Appointment;

import java.util.List;

public class AppointmentController {
    public List<Appointment> getAllAppointments() {
        return allAppointments;
    }

    public void setAllAppointments(List<Appointment> allAppointments) {
        this.allAppointments = allAppointments;
    }
}
